//JuneYeob Lee
//2462 9603
//CS471
ReadMe

1. File list
----------------
Main.java		Main file. 	
CreateCSV.java		class for creating result CSV file which includes average, Standard devation, Range, Median and Time.			 
Functions.java		class for 18 Functions  
MTRandom.java		MersenTwister file to create Random double
CreateMatrix.java	Create input data with Random double.
RandomWalk.java		Class to implement the Blind Algorithm (Iteration time from user)
LocalSearch.java	Class to omplement Local Search
IterativeLocalSearch.java	Class to implement the IterativeLocal Search (Iteration time from user)
Algorithm.java			Class to implement the GeneticAlgorithm and Differential evolution algorithm

2. Purpose
----------------
Project 3 aims to get optimized solution for 18 functions with 2 algorithms. One is Genetic Algorithm the other is Differential Evoltion.
Experiment is ongoing with 200 populations, 30 chromasomes, and 100 generations.

3. Design
-----------------
Algorithm class has 11 methods. 7 methods for Genetic Algorithm. 4 methods for Differential Evolution.
For the Genetic Algorithm. generate 100 solutions for 18 functions. select by Roulette wheel and proportionate method.
and crossover and then mutate.
For the Differential Evolution, mutate and combined and then crossover with 10 stratiges.

4.Build project with different IDE
-----------------------------------
Intellij user
4-1. Go to File--New--Project from existing Source.
4-2. Select NetBeans Project Directory
4-3. Import Project Wizard open. Select Create Project from Existing Sources
4-4  Follow on-screen instruction to continue

5. Run
---------------------
5-1. It will ask you number of populations(vectors) and size(chromazones).*required 200 populations and 30 chromazones.
5-2. It will ask you number of generations.* required 100 generations for experiment
5-3  For the Genetic Algorithm it will ask you number of crossover point.(1 or 2)
5-4 Out put will be the solution of 18 functions of each generation.
								
6. Expect result
-----------------
For each generation, solutions for 18 functions should be improved(decreased) or same as previous generation's result.
 
 