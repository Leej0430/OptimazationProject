//JuneYeob Lee
//2462 9603
//CS471
ReadMe

1. File list
----------------
Optimization1.java	Get the user input for input size  	
CreateCSV.java		class for creating result CSV file which includes average, Standard devation, Range, Median and Time.			
Functioning.java	Implement 18 functions with input 
Functions.java		class for 18 Functions  
MTRandom.java		MersenTwister file to create Random double
CreateMatrix.java	Create input data with Random double.

2. Purpose
----------------
Basically, project is aiming to get optimized and analyze result for 18 functions( Schwefel, Dejong, Rosenbrock,Rastrigin......)

3. Design
-----------------
Project is designed by myself. Used java language with netbeans IDE.


4. How to use (Java)
----------------
4-1. Click the Run button.

4-2. It will ask you length and size for input
(**input type should be integer** I recommend at least 30 for length dimension should be 10 or 20 or 30) 

4-3. Output will be the f(x) for created input 			
								
4-4. CSV file will be created which include average data, standard devation, Range, Median and Time for every functions.

5. Expect result
-----------------
There's no  exact value for the result because input data has created by random numbers.
However, Each functions results has specific bounds. 


 