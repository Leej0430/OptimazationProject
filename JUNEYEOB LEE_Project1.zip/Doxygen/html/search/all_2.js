var searchData=
[
  ['dejong',['DeJong',['../classoptimazation_1_1pkg1_1_1_functions.html#a2752fd139e24eabd03a2d9839b339126',1,'optimazation::pkg1::Functions']]]
];
