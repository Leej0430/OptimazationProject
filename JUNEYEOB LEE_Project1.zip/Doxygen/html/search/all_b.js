var searchData=
[
  ['quartic',['Quartic',['../classoptimazation_1_1pkg1_1_1_functions.html#af22c404472d06f7fc91cf892a726a346',1,'optimazation::pkg1::Functions']]]
];
