var searchData=
[
  ['levy',['Levy',['../classoptimazation_1_1pkg1_1_1_functions.html#a6a8f900f4661f8d498842f84276c7dea',1,'optimazation::pkg1::Functions']]]
];
