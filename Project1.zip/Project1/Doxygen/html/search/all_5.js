var searchData=
[
  ['griewangk',['Griewangk',['../classoptimazation_1_1pkg1_1_1_functions.html#a39192421da319de34fd6a2095498f78c',1,'optimazation::pkg1::Functions']]]
];
