var searchData=
[
  ['optimization1',['Optimization1',['../classoptimazation_1_1pkg1_1_1_optimization1.html',1,'optimazation::pkg1']]]
];
